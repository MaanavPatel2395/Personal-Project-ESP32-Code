//--------------------------------------------------------------------------------------------------
// telescope mount control, commands

#include "Mount.h"

#ifdef MOUNT_PRESENT

#include "../../lib/tasks/OnTask.h"
#include "../../lib/nv/Nv.h"

#include "site/Site.h"
#include "coordinates/Transform.h"
#include "goto/Goto.h"
#include "guide/Guide.h"
#include "limits/Limits.h"
#include "park/Park.h"

bool Mount::command(char *reply, char *command, char *parameter, bool *suppressFrame, bool *numericReply, CommandError *commandError) {
  char *conv_end;
  PrecisionMode precisionMode = PM_HIGH;

  if (command[0] == 'G') {
    // :GA#       Get Mount Altitude
    //            Returns: sDD*MM# or sDD*MM'SS# (based on precision setting)
    // :GAH#      High precision
    //            Returns: sDD*MM'SS.SSS# (high precision)
    if (command[1] == 'A' && (parameter[0] == 0 || parameter[1] == 0)) {
      if (parameter[0] == 'H') precisionMode = PM_HIGHEST; else if (parameter[0] != 0) { *commandError = CE_PARAM_FORM; return true; }
      double a = getPosition(CR_MOUNT_ALT).a;
      #if AXIS1_SECTOR_GEAR == OFF && AXIS2_TANGENT_ARM == OFF
        if (guide.state == GU_HOME_GUIDE || guide.state == GU_HOME_GUIDE_ABORT) {
          Coordinate homePosition = home.getPosition(CR_MOUNT_ALT);
          a = transform.mountToNative(&homePosition).a;
        }
      #endif
      convert.doubleToDms(reply, radToDeg(a), false, true, precisionMode);
      *numericReply = false;
    } else

    // :GD#       Get Mount Declination
    //            Returns: sDD*MM# or sDD*MM:SS# (based on precision setting)
    // :GDH#      Returns: sDD*MM:SS.SSS# (high precision)
    if (command[1] == 'D' && (parameter[0] == 0 || parameter[1] == 0)) {
      if (parameter[0] == 'H' || parameter[0] == 'e') precisionMode = PM_HIGHEST; else if (parameter[0] != 0) { *commandError = CE_PARAM_FORM; return true; }
      double d = getPosition().d;
      #if AXIS1_SECTOR_GEAR == OFF && AXIS2_TANGENT_ARM == OFF
        if (guide.state == GU_HOME_GUIDE || guide.state == GU_HOME_GUIDE_ABORT) {
          Coordinate homePosition = home.getPosition();
          d = transform.mountToNative(&homePosition).d;
        }
      #endif
      convert.doubleToDms(reply, radToDeg(d), false, true, precisionMode);
      *numericReply = false;
    } else

    // :GR#       Get Mount Right Ascension
    //            Returns: HH:MM.T# or HH:MM:SS# (based on precision setting)
    // :GRH#      Returns: HH:MM:SS.SSSS# (high precision)
    if (command[1] == 'R' && (parameter[0] == 0 || parameter[1] == 0)) {
      if (parameter[0] == 'H' || parameter[0] == 'a') precisionMode = PM_HIGHEST; else if (parameter[0] != 0) { *commandError = CE_PARAM_FORM; return true; }
      double r = getPosition().r;
      #if AXIS1_SECTOR_GEAR == OFF && AXIS2_TANGENT_ARM == OFF
        if (guide.state == GU_HOME_GUIDE || guide.state == GU_HOME_GUIDE_ABORT) {
          Coordinate homePosition = home.getPosition();
          r = transform.mountToNative(&homePosition).r;
        }
      #endif
      convert.doubleToHms(reply, radToHrs(r), false, precisionMode);
      *numericReply = false;
    } else

    // :GT#         Get tracking rate, 0.0 unless TrackingSidereal
    //              Returns: n.n# (OnStep returns more decimal places than LX200 standard)
    if (command[1] == 'T' && parameter[0] == 0)  {
      if (trackingState == TS_NONE) strcpy(reply,"0"); else sprintF(reply, "%0.5f", siderealToHz(trackingRate));
      *numericReply = false;
    } else 

    // :GX          OnStep extended command
    if (command[1] == 'X' && parameter[2] == 0)  {

      // :GX4[n]#   Get angles [n]
      //            (0 and 1) Returns instrument angle in: DDD:MM:SS#
      //            (2 and 3) Returns instrument angle in: n.nnnnnn#
      //            (4 and 5) Returns encoder angle in counts: n#
      if (parameter[0] == '4')  {
        *numericReply = false;
        switch (parameter[1]) {
          case '0': convert.doubleToDms(reply, radToDeg(axis1.getInstrumentCoordinate()), true, true, PM_HIGH); break;
          case '1': convert.doubleToDms(reply, radToDeg(axis2.getInstrumentCoordinate()), true, true, PM_HIGH); break; 
          case '2': sprintF(reply, "%0.6f", radToDeg(axis1.getInstrumentCoordinate())); break;
          case '3': sprintF(reply, "%0.6f", radToDeg(axis2.getInstrumentCoordinate())); break;
          case '4': sprintf(reply, "%ld", (long)axis1.motor->getEncoderCount()); break;
          case '5': sprintf(reply, "%ld", (long)axis2.motor->getEncoderCount()); break;
          default:  *numericReply = true; *commandError = CE_CMD_UNKNOWN;
        }
      } else

      // :GXE[m]#   Get mount setting
      //            Returns: n#
      if (parameter[0] == 'E')  {
        switch (parameter[1]) {
          case '4': sprintf(reply, "%ld", lround(axis1.getStepsPerMeasure()/RAD_DEG_RATIO)); *numericReply = false; break;
          case '5': sprintf(reply, "%ld", lround(axis2.getStepsPerMeasure()/RAD_DEG_RATIO)); *numericReply = false; break;
          case 'E': reply[0] = '0' + (MOUNT_COORDS - 1); *suppressFrame = true; *numericReply = false; break;
          case 'F': if (AXIS2_TANGENT_ARM != ON) *commandError = CE_0; break;
          case 'G': if (AXIS1_SECTOR_GEAR != ON) *commandError = CE_0; break;
          case 'M': sprintf(reply, "%d", (int)settings.mountType); *numericReply = false; break;
        default:
          return false;
        }
      } else

      // :GXFn#     Get frequency setting and workload
      //            Returns: Value
      if (parameter[0] == 'F')  {
        switch (parameter[1]) {
          case '3': sprintF(reply, "%0.6f", (axis1.getDirection() == DIR_FORWARD) ? axis1.getFrequencySteps() : -axis1.getFrequencySteps()); *numericReply = false; break;
          case '4': sprintF(reply, "%0.6f", (axis2.getDirection() == DIR_FORWARD) ? axis2.getFrequencySteps() : -axis2.getFrequencySteps()); *numericReply = false; break;
          case 'A': sprintf(reply, "%d%%", 50); *numericReply = false; break; // workload
          case 'F': // index position for Axis1
            sprintF(reply, "%0.6f", radToDeg(transform.instrumentToMount(axis1.getIndexPosition(), axis2.getIndexPosition()).a1));
            *numericReply = false;
          break;
          case 'G': // index position for Axis2
            sprintF(reply, "%0.6f", radToDeg(transform.instrumentToMount(axis1.getIndexPosition(), axis2.getIndexPosition()).a2));
            *numericReply = false;
          break;
        default:
          return false;
        }
      } else

      // :GXTD#     Get tracking rate offset Dec in arc-seconds/sidereal second
      //            Returns: n.nnnnnn#
      if (parameter[0] == 'T' && parameter[1] == 'D' && parameter[2] == 0) {
        sprintF(reply, "%0.8f", trackingRateOffsetDec*15.0F);
        *numericReply = false;
      } else

      // :GXTR#     Get tracking rate offset RA in arc-seconds/sidereal second
      //            Returns: n.nnnnnn#
      if (parameter[0] == 'T' && parameter[1] == 'R' && parameter[2] == 0) {
        sprintF(reply, "%0.8f", trackingRateOffsetRA*15.0F);
        *numericReply = false;
      } else return false;

    } else

    // :GZ#       Get Mount Azimuth
    //            Returns: DDD*MM# or DDD*MM'SS# (based on precision setting)
    // :GZH#      High precision
    //            Returns: DDD*MM'SS.SSS# (high precision)
    if (command[1] == 'Z' && (parameter[0] == 0 || parameter[1] == 0)) {
      if (parameter[0] == 'H') precisionMode = PM_HIGHEST; else if (parameter[0] != 0) { *commandError = CE_PARAM_FORM; return true; }
      double z = getPosition(CR_MOUNT_HOR).z;
      #if AXIS1_SECTOR_GEAR == OFF && AXIS2_TANGENT_ARM == OFF
        if (guide.state == GU_HOME_GUIDE || guide.state == GU_HOME_GUIDE_ABORT) {
          Coordinate homePosition = home.getPosition(CR_MOUNT_ALT);
          z = transform.mountToNative(&homePosition).z;
        }
      #endif
      convert.doubleToDms(reply, NormalizeAzimuth(radToDeg(z)), true, false, precisionMode);
      *numericReply = false;
    } else return false;
  } else

  if (command[0] == 'S') {
    //  :ST[H.H]# Set Tracking Rate in Hz where 60.0 is the solar rate
    //            Return: 0 on failure
    //                    1 on success
    if (command[1] == 'T') {
      double f = strtod(parameter,&conv_end);
      if (&parameter[0] != conv_end && ((f >= 30.0 && f < 90.0) || fabs(f) < 0.1)) {
        if (fabs(f) < 0.1) tracking(false); else {
          #if GOTO_FEATURE == ON
            if (park.state != PS_PARKED) {
              trackingRate = hzToSidereal(f);
              tracking(true);
            }
          #endif
        }
      } else *commandError = CE_PARAM_RANGE;
    } else

    //  :SEO#         Set coordinate origin for absolute encoders or mount coordinate memory
    //                Return: 0 on failure
    //                        1 on success
    if (command[1] == 'E' && parameter[0] == 'O' && parameter[1] == 0) {
      if (park.state == PS_PARKED) { *commandError = CE_PARKED; return true; }
      if (!mount.isTracking() && !mount.isSlewing()) {
        bool handled = false;

        #ifdef HAS_ABSOLUTE_ENCODER_SERVO
          handled = true;
          VLF("MSG: Mount, setting absolute encoder origin");

          #if AXIS1_ENCODER == SERIAL_BRIDGE && AXIS2_ENCODER == SERIAL_BRIDGE && defined(SERIAL_ENCODER)
            SERIAL_ENCODER.print(":SO#");
          #else
            uint32_t zero = (uint32_t)axis1.motor->encoderZero();
            V("MSG: Mount, absolute encoder saving AXIS1_ENCODER_OFFSET "); V(uint32_t(zero)); VLF(" to NV/EEPROM");
            nv().kv().put("AXIS1_ENCODER_ORIGIN", zero);

            zero = (uint32_t)axis2.motor->encoderZero();
            V("MSG: Mount, absolute encoder saving AXIS2_ENCODER_OFFSET "); V(uint32_t(zero)); VLF(" to NV/EEPROM");
            nv().kv().put("AXIS2_ENCODER_ORIGIN", zero);
          #endif

          #ifdef HAL_RESET
            enable(false);
            VLF("MSG: Mount, resetting OnStep...");
            if (nv().device().hasCommit()) { nv().device().commit(); }
            const uint32_t startMs = millis();
            const uint32_t timeoutMs = 5000;
            while (!nv().device().commitDone() && (uint32_t)(millis() - startMs) < timeoutMs) { tasks.yield(1); }
            tasks.yield(1000);
            HAL_RESET();
          #endif
        #endif

        #if MOUNT_COORDS_MEMORY == ON
          if (!handled && !goTo.absoluteEncodersPresent) {
            CommandError e = home.reset(true, true);
            if (e != CE_NONE) { *commandError = e; return true; }

            limits.enabled(site.isDateTimeReady());

            syncFromOnStepToEncoders = true;
            handled = true;

            VLF("MSG: Mount, setting mount coordinate memory origin");
          }
        #endif

        if (!handled) {
          *commandError = CE_0;
          DLF("MSG: Mount, setting coordinate origin failed; feature unavailable");
        }
      } else {
        *commandError = CE_0;
        DLF("MSG: Mount, setting coordinate origin failed; the mount is in motion!");
      }
    } else

    if (command[1] == 'X') {
      if (parameter[2] != ',') { *commandError = CE_PARAM_FORM; return true; }

      // :SX4[m],[n]#   Set encoder axis [m] to value [n]
      //                Return: 0 on failure
      //                        1 on success
      if (parameter[0] == '4') {
        double d;
        static double encoderAxis1 = NAN;
        static double encoderAxis2 = NAN;

        switch (parameter[1]) {

          // stage encoder Axis1 value (depreciated)
          case '0':
            d = strtod(&parameter[3], &conv_end);
            if (&parameter[3] != conv_end && fabs(d) <= 360.0L) { encoderAxis1 = degToRad(d); } else { encoderAxis1 = NAN; *commandError = CE_PARAM_RANGE; }
          break;

          // stage encoder Axis2 value (depreciated)
          case '1':
            d = strtod(&parameter[3], &conv_end);
            if (&parameter[3] != conv_end && fabs(d) <= 360.0L) { encoderAxis2 = degToRad(d); } else { encoderAxis2 = NAN; *commandError = CE_PARAM_RANGE; }
          break;

          // sync from encoder values (depreciated)
          case '2':
            if (parameter[3] == '1' && parameter[4] == 0) {
              #if GOTO_FEATURE == ON
                CommandError e = goTo.validate();
                if (e != CE_NONE) { *commandError = e; return true; }
              #endif
              if (isnan(encoderAxis1) || isnan(encoderAxis2) || syncFromOnStepToEncoders) { *commandError = CE_0; return true; }
              *commandError = limits.validateInstrumentCoordinate(1, encoderAxis1, true);
              if (*commandError == CE_NONE) *commandError = limits.validateInstrumentCoordinate(2, encoderAxis2, true);
              if (*commandError != CE_NONE) return true;
              *commandError = limits.setInstrumentCoordinate(1, encoderAxis1, true);
              if (*commandError == CE_NONE) *commandError = limits.setInstrumentCoordinate(2, encoderAxis2, true);
              if (*commandError != CE_NONE) return true;
            }
          break;

          // allow sws to control sync mode
          case '3': syncFromOnStepToEncoders = false; break;

          // set and sync from encoder Axis1 and Axis2 values
          // append 'a' if both SWS encoder values are absolute and trusted
          case '4': {
            bool absoluteAuthority = false;
            d = strtod(&parameter[3], &conv_end);
            if (&parameter[3] != conv_end && fabs(d) <= 360.0L) { encoderAxis1 = degToRad(d); } else { encoderAxis1 = NAN; }

            char *parameter2 = strchr(&parameter[3], ','); parameter2++;
            d = strtod(parameter2, &conv_end);
            if (parameter2 != conv_end && fabs(d) <= 360.0L) {
              encoderAxis2 = degToRad(d);
              if (conv_end[0] == 'a' && conv_end[1] == 0) absoluteAuthority = true; else
              if (conv_end[0] != 0) encoderAxis2 = NAN;
            } else { encoderAxis2 = NAN; }

            #if GOTO_FEATURE == ON
              CommandError e = goTo.validate();              
              if (e != CE_NONE && e != CE_SLEW_ERR_IN_STANDBY && e != CE_SLEW_IN_SLEW) { *commandError = e; return true; }
            #endif

            if ( isnan(encoderAxis1) ||
                 isnan(encoderAxis2) ||
                 syncFromOnStepToEncoders ||
                 (goTo.state != GS_NONE && goTo.stage != GG_NEAR_DESTINATION_WAIT) ||
                 guide.state != GU_NONE) { *commandError = CE_0; return true; }

            *commandError = limits.validateInstrumentCoordinate(1, encoderAxis1, true);
            if (*commandError == CE_NONE) *commandError = limits.validateInstrumentCoordinate(2, encoderAxis2, true);
            if (*commandError != CE_NONE) return true;
            *commandError = limits.setInstrumentCoordinate(1, encoderAxis1, true);
            if (*commandError == CE_NONE) *commandError = limits.setInstrumentCoordinate(2, encoderAxis2, true);
            if (*commandError != CE_NONE) return true;
            if (absoluteAuthority) {
              captureNominalIndexPositions();
              setStartupAuthorityTrusted(true);
              goTo.absoluteEncodersPresent = true;
              goTo.encodersPresent = true;
              VLF("MSG: Mount, sync from trusted paired absolute SWS encoders");
            }
          break; }

          default: *commandError = CE_CMD_UNKNOWN; break;
        }
      } else

      // :SXEM,[n]#   Set mount type (for next restart) where n=0 for default
      //              Return: 0 on failure
      //                      1 on success
      if (parameter[0] == 'E' && parameter[1] == 'M') {
        long mountType = atol(&parameter[3]);
        if (mountType == 0 ||
            (mountType == GEM && AXIS1_WRAP == OFF) ||
            (mountType == FORK && AXIS1_WRAP == OFF) ||
            (mountType == ALTAZM && AXIS2_TANGENT_ARM == OFF)) {
          settings.mountType = mountType;
          nv().kv().put(nvKey, settings);
        } else *commandError = CE_PARAM_RANGE;
      } else

      // :SXTD,n.n#   Set tracking rate offset Dec in arc-seconds/sidereal second
      //              Return: 0 on failure
      //                      1 on success
      if (parameter[0] == 'T' && parameter[1] == 'D') {
        float f = strtod(&parameter[3], &conv_end);
        if (f < -1800.0F) f = -1800.0F;
        if (f > 1800.0F) f = 1800.0F;
        trackingRateOffsetDec = f/15.0F;
      } else

      // :SXTR,n.n# Set tracking rate offset RA in arc-seconds/sidereal second
      //            Return: 0 failure, 1 success
      if (parameter[0] == 'T' && parameter[1] == 'R') {
        float f = strtod(&parameter[3], &conv_end);
        if (f < -1800.0F) f = -1800.0F;
        if (f > 1800.0F) f = 1800.0F;
        trackingRateOffsetRA = f/15.0F;
      } else return false;

    } else return false;
  } else

  // T - Tracking Commands
  //
  // :TS#       Track rate solar    60Hz
  // :TK#       Track rate king     60.136Hz
  // :TL#       Track rate lunar    57.9Hz
  // :TQ#       Track rate sidereal 60.164Hz
  //
  // :T+#       Master sidereal clock faster by 0.02 Hertz (stored in EEPROM)
  // :T-#       Master sidereal clock slower by 0.02 Hertz (stored in EEPROM)
  // :TR#       Master sidereal clock reset (to calculated sidereal rate, stored in EEPROM)
  //            Returns: Nothing
  //
  // :Te#       Tracking enable
  // :Td#       Tracking disable
  //
  // :To#       Track full compensation on
  // :Tr#       Track refraction compensation on
  // :Tn#       Track compensation off
  // :T1#       Track dual axis off (disable Dec tracking on Eq mounts)
  // :T2#       Track dual axis on
  //            Return: 0 on failure
  //                    1 on success
  if (command[0] == 'T' && parameter[0] == 0) {
    if (command[1] == 'o') { settings.rc = RC_MODEL; } else
    if (command[1] == 'r') { settings.rc = RC_REFRACTION; } else
    if (command[1] == 'n') { settings.rc = RC_NONE; } else
    if (command[1] == '1') {
      if (settings.rc == RC_REFRACTION_DUAL) settings.rc = RC_REFRACTION; else
      if (settings.rc == RC_MODEL_DUAL) settings.rc = RC_MODEL;
    } else
    if (command[1] == '2') {
      if (settings.rc == RC_REFRACTION) settings.rc = RC_REFRACTION_DUAL; else
      if (settings.rc == RC_MODEL) settings.rc = RC_MODEL_DUAL;
    } else
    if (command[1] == 'S') { trackingRate = hzToSidereal(SOLAR_RATE_HZ); } else
    if (command[1] == 'K') { trackingRate = hzToSidereal(KING_RATE_HZ); } else
    if (command[1] == 'L') { trackingRate = hzToSidereal(LUNAR_RATE_HZ); } else
    if (command[1] == 'Q') { trackingRate = hzToSidereal(SIDEREAL_RATE_HZ); } else
    if (command[1] == '+') { site.setSiderealPeriod(site.getSiderealPeriod() - hzToSubMicros(0.02F)); } else
    if (command[1] == '-') { site.setSiderealPeriod(site.getSiderealPeriod() + hzToSubMicros(0.02F)); } else
    if (command[1] == 'R') { site.setSiderealPeriod(SIDEREAL_PERIOD); } else
    if (command[1] == 'e') {
      #if GOTO_FEATURE == ON
        if (park.state != PS_PARKED) {
      #endif
      tracking(true);
      #if GOTO_FEATURE == ON
        } else *commandError = CE_PARKED;
      #endif
    } else
    if (command[1] == 'd') {
      tracking(false);
    } else *commandError = CE_CMD_UNKNOWN;

    if (!transform.isEquatorial()) {
      if (settings.rc == RC_MODEL) settings.rc = RC_MODEL_DUAL;
      if (settings.rc == RC_REFRACTION) settings.rc = RC_REFRACTION_DUAL;
    }

    if (*commandError == CE_NONE) {
      switch (command[1]) { case 'S': case 'K': case 'L': case 'Q': case '+': case '-': case 'R': *numericReply = false; }
      nv().kv().put(nvKey, settings);
      update();
    }
  } else

  //  $ - Set parameter
  // :$BD[n]#   Set Dec/Alt backlash in arc-seconds
  //            Return: 0 on failure
  //                    1 on success
  // :$BR[n]#   Set RA/Azm backlash in arc-seconds
  //            Return: 0 on failure
  //                    1 on success
  //        Set the Backlash values.  Units are arc-seconds
  if (command[0] == '$' && command[1] == 'B') {
    int16_t arcSecs;
    if (convert.atoi2((char*)&parameter[1], &arcSecs)) {
      if (arcSecs >= 0 && arcSecs <= 3600) {
        if (parameter[0] == 'D') {
          settings.backlash.axis2 = arcsecToRad(arcSecs);
          axis2.setBacklash(settings.backlash.axis2);
          nv().kv().put(nvKey, settings);
        } else
        if (parameter[0] == 'R') {
          settings.backlash.axis1 = arcsecToRad(arcSecs);
          axis1.setBacklash(settings.backlash.axis1);
          nv().kv().put(nvKey, settings);
        } else *commandError = CE_CMD_UNKNOWN;
      } else *commandError = CE_PARAM_RANGE;
    } else *commandError = CE_PARAM_FORM;
  } else

  //  % - Return parameter
  // :%BD#      Get Dec/Alt Antibacklash value in arc-seconds
  //            Return: n#
  // :%BR#      Get RA/Azm Antibacklash value in arc-seconds
  //            Return: n#
  if (command[0] == '%' && command[1] == 'B' && parameter[1] == 0) {
    if (parameter[0] == 'D') {
        int arcSec = round(radToArcsec(settings.backlash.axis2));
        if (arcSec < 0) arcSec = 0;
        if (arcSec > 3600) arcSec = 3600;
        sprintf(reply, "%d", arcSec);
        *numericReply = false;
    } else
    if (parameter[0] == 'R') {
        int arcSec = round(radToArcsec(settings.backlash.axis1));
        if (arcSec < 0) arcSec = 0;
        if (arcSec > 3600) arcSec = 3600;
        sprintf(reply, "%d", arcSec);
        *numericReply = false;
    } else *commandError = CE_CMD_UNKNOWN;
  } else return false;

  return true;
}

#endif
