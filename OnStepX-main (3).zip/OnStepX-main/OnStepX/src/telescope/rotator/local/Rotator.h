//--------------------------------------------------------------------------------------------------
// local telescope rotator control
#pragma once

#include "../../../Common.h"

#include "../RotatorBase.h"

#ifdef ROTATOR_PRESENT

#include "../../../lib/nv/Nv.h"
#include "../../../lib/axis/Axis.h"
#include "../../../libApp/commands/ProcessCmds.h"
#include "../../Telescope.h"
#include "../../mount/coordinates/Transform.h"

#pragma pack(1)
#define RotatorSettingsSize 11
typedef struct RotatorSettings {
  ParkState parkState;
  int16_t backlash;  // in steps
  float position;    // in degrees
  float gotoRate;    // in degrees/s
} RotatorSettings;
#pragma pack()

#ifdef ROTATOR_CAN_SERVER_PRESENT
#include "../../../lib/canTransport/CanTransportServer.h"
class Rotator : public CanTransportServer {
private:
  void processCommand() override;
public:
  Rotator() : CanTransportServer((uint16_t)(CAN_ROTATOR_REQ_ID), (uint16_t)(CAN_ROTATOR_RSP_ID)) {}
#else
class Rotator {
public:
#endif

  // initialize rotator
  bool init();
  void begin();

  // process rotator commands
  bool command(char *reply, char *command, char *parameter, bool *suppressFrame, bool *numericReply, CommandError *commandError);

  // poll rotator to handle parking and derotation
  void monitor();

private:
  // get backlash in steps
  int getBacklash();

  // set backlash in steps
  CommandError setBacklash(int value);

  #ifdef MOUNT_PRESENT
    // returns parallactic angle in degrees
    double parallacticAngle(Coordinate *coord);

    // returns parallactic rate in degrees per second
    double parallacticRate(Coordinate *coord);
  #endif

  // set move rate
  void setMoveRate(int value);

  // start slew in the specified direction
  CommandError move(Direction dir);

  // get goto rate, 1 for 0.5x base, 2 for 0.66x base, 3 for base, 4 for 1.5x base, 5 for 2x base
  int getGotoRate();

  // set goto rate, 1 for 0.5x base, 2 for 0.66x base, 3 for base, 4 for 1.5x base, 5 for 2x base
  void setGotoRate(int value);

  // move rotator to a specific location
  CommandError gotoTarget(float target);

  // parks rotator at current position
  CommandError park();

  // unparks rotator
  CommandError unpark();

  float moveRate = 0.1;  // in degs/sec

  RotatorSettings settings = {PS_UNPARKED, 0, 0.0F, AXIS3_SLEW_RATE_BASE_DESIRED};

  bool ready = false;

  bool derotatorEnabled = false;
  bool derotatorReverse = false;
  bool homing = false;

  unsigned long writeTime = 0;
  unsigned long secs = 0;

  uint8_t parkHandle = 0;

  uint16_t writeDelay = 600; // time in seconds
  uint32_t nvKey;
};

extern Motor& motor3;
extern Axis axis3;

extern Rotator rotator;

#endif
