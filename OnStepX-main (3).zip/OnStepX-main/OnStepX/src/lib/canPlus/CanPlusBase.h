// -----------------------------------------------------------------------------------
// CAN library
#pragma once

#include "../../Common.h"

#if defined(CAN_PLUS) && CAN_PLUS != OFF

#ifndef DEBUG_CAN
#define DEBUG_CAN                     OFF
#endif

#ifndef CAN_BAUD
#define CAN_BAUD                      1000000                   // 1000000 baud default
#endif
#ifndef CAN_SEND_RATE_MS
#define CAN_SEND_RATE_MS              10                        // 100 Hz CAN controller send message processing rate
#endif
#ifndef CAN_RECV_RATE_MS
#define CAN_RECV_RATE_MS              2                         // 500 Hz CAN controller recv. message processing rate
#endif
#ifndef CAN_RX_PIN
#define CAN_RX_PIN                    OFF                       // for ESP32 CAN interface
#endif
#ifndef CAN_TX_PIN
#define CAN_TX_PIN                    OFF                       // for ESP32 CAN interface
#endif
#ifndef CAN_CS_PIN
#define CAN_CS_PIN                    OFF                       // for MCP2515 SPI CAN controller
#endif
#ifndef CAN_INT_PIN
#define CAN_INT_PIN                   OFF                       // for MCP2515 SPI CAN controller
#endif

#ifndef CAN_BURST_WINDOW_US
#define CAN_BURST_WINDOW_US           1000                      // for polling recv. how long to wait during a burst
#endif

#ifndef CAN_MAX_CALLBACKS
  #define CAN_MAX_CALLBACKS           16
#endif

class CanPlus {
  public:
    virtual ~CanPlus() = default;
    virtual int beginPacket(int id);
    virtual int endPacket();
    virtual int write(uint8_t byte);
    virtual int write(const uint8_t *buffer, size_t size);
    virtual int writePacket(int id, const uint8_t *buffer, size_t size);
    // RTR policy: supports sending RTR, but drops on receive
    virtual int writePacketRtr(int id, size_t dlc) { UNUSED(id); UNUSED(dlc); return 0; }

    virtual int callbackRegisterId(int id, void (*callback)(uint8_t data[8]));
    virtual int callbackRegisterMessage(int id, uint8_t msg, void (*callback)(uint8_t data[8]));

    virtual int callbackRegisterId(int id, void (*callback)(uint8_t data[8], uint8_t len));
    virtual int callbackRegisterMessage(int id, uint8_t msg, void (*callback)(uint8_t data[8], uint8_t len));

    virtual int callbackProcess(int id, uint8_t *buffer, size_t size);

    // send pacing, non-blocking
    bool txTryLock(uint32_t minGapUs = defaultPacingUs());

    // send pacing, blocking
    void txWait(uint32_t minGapUs = defaultPacingUs());

    // allow any polling recv that may be present to happen quickly for a short period of time
    // this increases the polling rate to 1ms for the specified period in microseconds
    virtual void rxBurst(uint32_t periodUs = 2000) { UNUSED(periodUs); }

    static inline uint32_t defaultPacingUs() { return (uint32_t)CAN_SEND_RATE_MS*1000UL; }

    bool ready = false;

    inline void resetStats() {
      noInterrupts();
      tx_ok = 0;
      tx_fail = 0;
      rx_ok = 0;
      rx_drop_ext = 0;
      rx_drop_rtr = 0;
      rx_drop_len = 0;
      interrupts();
    }

    volatile uint32_t rx_ok = 0;
    volatile uint32_t rx_drop_ext = 0;
    volatile uint32_t rx_drop_rtr = 0;
    volatile uint32_t rx_drop_len = 0;
    volatile uint32_t tx_ok = 0;
    volatile uint32_t tx_fail = 0;

  protected:
    int sendId = 0;
    int sendCount = -1;
    uint8_t sendData[8] = {0};
    
    int idCallbackCount = 0;
    int idCallBackId[CAN_MAX_CALLBACKS] = {0};
    void (*idCallback[CAN_MAX_CALLBACKS])(uint8_t data[8]) = {nullptr};
    void (*idCallbackEx[CAN_MAX_CALLBACKS])(uint8_t data[8], uint8_t len) = {nullptr};

    int msgCallbackCount = 0;
    int msgCallBackId[CAN_MAX_CALLBACKS] = {0};
    int msgCallBackMsg[CAN_MAX_CALLBACKS] = {0};
    void (*msgCallback[CAN_MAX_CALLBACKS])(uint8_t data[8]) = {nullptr};
    void (*msgCallbackEx[CAN_MAX_CALLBACKS])(uint8_t data[8], uint8_t len) = {nullptr};

    uint32_t lastTxUs = 0;
    
    // for recv. path loops if present
    const uint32_t budgetUs = 200;  // tune ~ 100–300us
    const int maxFrames = 8;        // cap frames that are processed per CAN_RECV_RATE_MS, must be >= 2
};

#endif