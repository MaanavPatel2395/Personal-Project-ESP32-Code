// -------------------------------------------------------------------------------------------------
// Pin map for OnStep MaxESP Version 3.x (ESP32S)
#pragma once

#if defined(MyBoard)

// Serial0: RX Pin GPIO3, TX Pin GPIO1 (to USB serial adapter)
// Serial1: RX1 Pin GPIO10, TX1 Pin GPIO9 (on SPI Flash pins, must be moved to be used)
// Serial2: RX2 Pin GPIO16, TX2 Pin GPIO17

#if SERIAL_A_BAUD_DEFAULT != OFF
  #define SERIAL_A              Serial
#endif
#ifdef SERIAL_B
  #undef SERIAL_B
#endif

// Use the following settings for any TMC UART driver (TMC2209) that may be present
/*
#if defined(STEP_DIR_TMC_UART_PRESENT) || defined(SERVO_TMC2209_PRESENT)
  #if defined(SERIAL_TMC_HARDWARE_UART)
    #define SERIAL_TMC          Serial1          // Use a single hardware serial port to up to four drivers
    #define SERIAL_TMC_BAUD     460800           // Baud rate
    #define SERIAL_TMC_RX       OFF               // Recieving data
    #define SERIAL_TMC_TX       OFF               // Transmit data
    #define SERIAL_TMC_ADDRESS_MAP(x) ((x==4)?2 : x) // Axis1(0) is 0, Axis2(1) is 1, Axis3(2) is 2, Axis4(3) is 3, Axis5(4) is 2
  #endif
#endif

*/
#define AXIS1_SERVO_PH1_PIN     OFF
#define AXIS1_SERVO_PH2_PIN     OFF
#define AXIS2_SERVO_PH1_PIN     OFF
#define AXIS2_SERVO_PH2_PIN     OFF
#define TMC_SPI_HW_PINS         ON    // Forces use of 18, 19, 23
#define SERIAL_TMC              OFF   // Kills the secondary serial check
#define ST4_INTERFACE           OFF   // Kills the autoguider port logic
#define TONE_PIN                OFF
#define STATUS_BUZZER_PIN       OFF
#define RETICLE_LED_PIN         OFF
// Uses default ESP32 I2C GPIO21 (SDA) and GPIO22 (SCL)

// The multi-purpose pins (Aux3..Aux8 can be analog pwm/dac if supported)
#define AUX2_PIN                OFF                // ESP8266 RST control, or MISO for Axis1&2, or Axis4 EN support
#define AUX3_PIN                OFF               // Home SW for Axis1, or I2C SDA
#define AUX4_PIN                OFF               // Home SW for Axis2, or I2C SCL
#define AUX7_PIN                OFF               // Limit SW, PPS, etc.
#define AUX8_PIN                OFF               // 1-Wire, Status LED, Reticle LED, Tone, etc.

// Misc. pins
#ifndef ONE_WIRE_PIN
  #define ONE_WIRE_PIN          OFF         // Default Pin for OneWire bus
#endif
#define ADDON_GPIO0_PIN         OFF         // ESP8266 GPIO0 (Dir2)
#ifndef ADDON_RESET_PIN
  #define ADDON_RESET_PIN       OFF         // ESP8266 RST
#endif

// The PEC index sense is a logic level input, resets the PEC index on rising edge then waits for 60 seconds before allowing another reset
#ifndef PEC_SENSE_PIN
  #define PEC_SENSE_PIN         OFF               // [input only 36] PEC Sense, analog (A0) or digital (GPIO36)
#endif

// The status LED is a two wire jumper with a 2k resistor in series to limit the current to the LED
#ifndef STATUS_LED_PIN
  #define STATUS_LED_PIN        OFF         // Default LED Cathode (-)
#endif
#define MOUNT_LED_PIN           OFF   // Default LED Cathode (-)
#ifndef RETICLE_LED_PIN 
  #define RETICLE_LED_PIN       OFF   // Default LED Cathode (-)
#endif

// For a piezo buzzer
#ifndef STATUS_BUZZER_PIN
  #define STATUS_BUZZER_PIN     OFF         // Tone
#endif

// The PPS pin is a 3.3V logic input, OnStep measures time between rising edges and adjusts the internal sidereal clock frequency
#ifndef PPS_SENSE_PIN
  #define PPS_SENSE_PIN         OFF         // PPS time source, GPS for example
#endif

// The limit switch sense is a logic level input normally pull high (2k resistor,) shorted to ground it stops gotos/tracking
#ifndef LIMIT_SENSE_PIN
  #define LIMIT_SENSE_PIN       OFF
#endif

#define SPI_SCLK_PIN  18
#define SPI_MISO_PIN  19
#define SPI_MOSI_PIN  23
                                                 // Hint that the direction pins are shared
#define SHARED_ENABLE_PIN       13              // Hint that the enable pins are shared

// Axis1 RA/Azm step/dir driver
#define AXIS1_ENABLE_PIN        SHARED_ENABLE_PIN           // [must be low at boot 12]
#define AXIS1_STEP_PIN          25
#define AXIS1_DIR_PIN           33             // [must be high at boot 0]
#define AXIS1_M2_PIN            4
#ifndef AXIS1_SENSE_HOME_PIN
  #define AXIS1_SENSE_HOME_PIN  OFF
#endif
#define AXIS1_FAULT_SENSE_PIN   OFF
#define AXIS1_DIAG_PIN          OFF

// Axis2 Dec/Alt step/dir driver
#define AXIS2_ENABLE_PIN        SHARED_ENABLE_PIN           // [must be low at boot 12]
#define AXIS2_STEP_PIN          27
#define AXIS2_DIR_PIN           32              // [must be high at boot 0]
#define AXIS2_M2_PIN            16
#ifndef AXIS2_SENSE_HOME_PIN
  #define AXIS2_SENSE_HOME_PIN  OFF
#endif
#define AXIS2_FAULT_SENSE_PIN   OFF
#define AXIS2_DIAG_PIN          OFF

// For rotator stepper driver
#define AXIS3_ENABLE_PIN        OFF              // No enable pin control (always enabled)
#define AXIS3_M0_PIN            OFF              // SPI MOSI
#define AXIS3_M1_PIN            OFF              // SPI SCK
#define AXIS3_M2_PIN            OFF              // SPI CS (UART TX)
#define AXIS3_M3_PIN            OFF              // SPI MISO (UART RX)
#define AXIS3_STEP_PIN          OFF                // [must be low at boot 2]
#define AXIS3_DIR_PIN           OFF

// For focuser1 stepper driver
#if !defined(SERIAL_TMC_HARDWARE_UART) && AXIS4_POWER_DOWN == ON
  #define AXIS4_ENABLE_PIN      OFF
#endif
#define AXIS4_M0_PIN            OFF              // SPI MOSI
#define AXIS4_M1_PIN            OFF              // SPI SCK
#define AXIS4_M2_PIN            OFF              // SPI CS (UART TX)
#define AXIS4_M3_PIN            OFF              // SPI MISO (UART RX)
#define AXIS4_STEP_PIN          OFF
#define AXIS4_DIR_PIN           OFF

// For focuser2 stepper driver
#define AXIS5_ENABLE_PIN        OFF              // No enable pin control (always enabled)
#define AXIS5_M0_PIN            OFF              // SPI MOSI
#define AXIS5_M1_PIN            OFF              // SPI SCK
#define AXIS5_M2_PIN            OFF              // SPI CS (UART TX)
#define AXIS5_M3_PIN            OFF              // SPI MISO (UART RX)
#define AXIS5_STEP_PIN          OFF
#define AXIS5_DIR_PIN           OFF

// ST4 interface
#define ST4_RA_W_PIN            OFF               // [input only 34] ST4 RA- West
#define ST4_DEC_S_PIN           OFF               // ST4 DE- South
#define ST4_DEC_N_PIN           OFF               // ST4 DE+ North
#define ST4_RA_E_PIN            OFF               // [input only 35] ST4 RA+ East

#define WIFI_LED_PIN            OFF
#define BT_LED_PIN              OFF

#else
#error "Wrong processor for this configuration!"

#endif
